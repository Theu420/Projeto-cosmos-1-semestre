(() => {
  "use strict";

  // fases
  const PHASES = [
    {
      id: "adicao",
      name: "ADIÇÃO",
      title: "A Cintura de Asteroides",
      op: "+",
      bg: "assets/background_adicao.jpg",
      speed: 30,
      spawnMs: 2200,
      maxOnScreen: 3,
      before:
        "Vocês acham que podem resistir? Vou adicionar mais e mais rochas à sua trajetória. Vamos ver se a sua mente consegue somar a velocidade dos meus projéteis antes de virar poeira!",
      lose:
        "Uma conta tão simples... e vocês falharam. O seu planeta agora é apenas mais um número na minha lista de destruição.",
      win:
        "Argh... Vocês conseguiram repelir a primeira onda somando suas forças? Não importa. Isso foi apenas o aquecimento.",
    },
    {
      id: "subtracao",
      name: "SUBTRAÇÃO",
      title: "A Órbita de Marte",
      op: "−",
      bg: "assets/background_subtracao.jpg",
      speed: 30,
      spawnMs: 1900,
      maxOnScreen: 3,
      before:
        "Vocês sobreviveram ao primeiro impacto, mas agora o tempo de vocês será reduzido a zero! A cada segundo, subtrairei suas chances de sobrevivência. Consigam acompanhar isso!",
      lose:
        "Subtraídos da existência... Como eu previ. O vazio é o único resultado lógico para vocês.",
      win:
        "Impossível! Vocês conseguiram anular minhas forças novamente? Minha frota está diminuindo... Mas a próxima onda vai esmagá-los!",
    },
    {
      id: "multiplicacao",
      name: "MULTIPLICAÇÃO",
      title: "A Termosfera Terrestre",
      op: "×",
      bg: "assets/background_multiplicacao.jpg",
      speed: 30,
      spawnMs: 1600,
      maxOnScreen: 4,
      before:
        "Chega de brincadeiras! Se uma rocha não foi suficiente, que tal dezenas delas? Vou multiplicar meus ataques! Seus canhões não serão rápidos o bastante para calcular essa densidade!",
      lose:
        "Uma derrota multiplicada pelo seu fracasso. O fim da Terra foi calculado com sucesso.",
      win:
        "O quê?! Como vocês conseguiram processar tantos alvos ao mesmo tempo? Minha paciência está se esgotando!",
    },
    {
      id: "divisao",
      name: "DIVISÃO",
      title: "O Confronto Final",
      op: "÷",
      bg: "assets/background_divisao.jpg",
      speed: 30,
      spawnMs: 1450,
      maxOnScreen: 4,
      before:
        "Vocês chegaram até mim, mas este é o fim da linha. Eu trarei a divisão definitiva! Vou despedaçar o seu planeta e dividir suas cinzas pelo cosmos! Resolvam esta equação final se forem capazes!",
      lose:
        "Divididos... e conquistados. O universo agora está em perfeita ordem sem a sua existência.",
      win:
        "Não... Meus cálculos... estavam perfeitos! Como uma mente orgânica pôde superar a minha precisão absoluta?! Meu império... foi reduzido a zero... NÃAAAAO!",
    },
  ];

  const INTRO_TEXT =
    "Habitantes desse planeta insignificante... Sua existência é matematicamente irrelevante. Eu sou o Lorde Void, e decretei o fim do seu mundo. Meus meteoros estão a caminho. Não há fórmula que possa salvá-los!";

  const MAX_LIVES = 3;
  const POINTS_HIT = 100;
  const POINTS_PHASE = 250;

  // refs da tela (elementos do html)
  function $(seletor) {
    return document.querySelector(seletor);
  }

  const ui = {
    title: $("#screen-title"),
    dialog: $("#screen-dialog"),
    play: $("#screen-play"),
    gameover: $("#screen-gameover"),
    victory: $("#screen-victory"),
    dialogBg: $("#dialog-bg"),
    dialogText: $("#dialog-text"),
    playBg: $("#play-bg"),
    meteorField: $("#meteor-field"),
    laserLayer: $("#laser-layer"),
    answer: $("#answer-input"),
    ship: $("#ship"),
    hudPhase: $("#hud-phase"),
    hudOp: $("#hud-op"),
    hudScore: $("#hud-score"),
    hudLives: $("#hud-lives"),
    goScore: $("#go-score"),
    goQuote: $("#go-quote"),
    winScore: $("#win-score"),
    winQuote: $("#win-quote"),
    btnStart: $("#btn-start"),
    btnFire: $("#btn-fire"),
    btnRetry: $("#btn-retry"),
    btnAgain: $("#btn-again"),
  };

  // guarda os estados durante o jogo
  const state = {
    contas: null,
    phaseIndex: 0,
    score: 0,
    lives: MAX_LIVES,
    queue: [],
    meteors: [],
    playing: false,
    lastTs: 0,
    spawnAcc: 0,
    raf: 0,
    dialogQueue: [],
    dialogIndex: 0,
    typing: false,
    typeTimer: 0,
    fullText: "",
    typedLen: 0,
    onDialogDone: null,
    audioCtx: null,
  };

  // funções auxioliares

  // troca de tela
  function showScreen(screen) {
    const telas = [ui.title, ui.dialog, ui.play, ui.gameover, ui.victory];
    for (let i = 0; i < telas.length; i++) {
      telas[i].classList.remove("active");
    }
    screen.classList.add("active");
  }

  // navegador precisa dessa função pra funcionar o audio
  function ensureAudio() {
    if (!state.audioCtx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) {
        state.audioCtx = new AC();
      }
    }
    if (state.audioCtx && state.audioCtx.state === "suspended") {
      state.audioCtx.resume();
    }
  }

  // efeitinho do beep
  function beep(freq = 880, dur = 0.04, type = "square", gain = 0.03) {
    if (!state.audioCtx) return;
    const ctx = state.audioCtx;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    g.gain.value = gain;
    osc.connect(g);
    g.connect(ctx.destination);
    osc.start();
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    osc.stop(ctx.currentTime + dur);
  }

  // efeitinho do beep mas com um delay
  function tocarBeepComAtraso(freq, dur, type, gain, atrasoMs) {
    setTimeout(() => {
      beep(freq, dur, type, gain);
    }, atrasoMs);
  }

  // função pra tirar os meteoros, mensagens, etc com um delay pra ficar estiloso
  function removerElementoComAtraso(elemento, atrasoMs) {
    setTimeout(() => {
      elemento.remove();
    }, atrasoMs);
  }

  // atualiza as bolinhas de vida
  function atualizarVidasNaTela() {
    ui.hudLives.innerHTML = "";
    for (let i = 0; i < MAX_LIVES; i++) {
      const pip = document.createElement("span");
      if (i >= state.lives) {
        pip.className = "life-pip lost";
      } else {
        pip.className = "life-pip";
      }
      ui.hudLives.appendChild(pip);
    }
  }

  // muda o nmr da fase, nome da operaçao, placar e vidas na interface
  function updateHud() {
    const phase = PHASES[state.phaseIndex];
    ui.hudPhase.textContent = String(state.phaseIndex + 1);

    if (phase) {
      ui.hudOp.textContent = phase.name;
    } else {
      ui.hudOp.textContent = "—";
    }

    ui.hudScore.textContent = String(state.score);
    atualizarVidasNaTela();
  }

  // define a imagem de fundo de um elemento da tela
  function setBackground(el, src) {
    el.style.backgroundColor = "#12081f";
    el.style.backgroundImage = `url("${src}")`;
    el.style.backgroundSize = "cover";
    el.style.backgroundPosition = "center top";
    el.style.backgroundRepeat = "no-repeat";
  }

  // monta com quebra de linha o texto da conta de dentro do meteoro
  function formatEq(n1, op, n2) {
    return `${n1}\n${op}\n${n2}`;
  }

  // embaralhar a lista de contas pra madar os meteoros de forma aleatoria
  function shuffle(lista) {
    const embaralhado = lista.slice();

    for (let i = embaralhado.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));

      const temp = embaralhado[i];
      embaralhado[i] = embaralhado[j];
      embaralhado[j] = temp;
    }

    return embaralhado;
  }

  // monta a fila de contas de uma fase (usando a função de cima pra embaralhar)
  function buildQueue(phase) {
    const contasDaFase = state.contas[phase.id] || [];
    const contasEmbaralhadas = shuffle(contasDaFase);
    const fila = [];

    for (let i = 0; i < contasEmbaralhadas.length; i++) {
      const item = contasEmbaralhadas[i];
      fila.push({
        n1: item.n1,
        n2: item.n2,
        result: item.result,
        op: phase.op,
      });
    }

    return fila;
  }

  // funções dos dialogos
  function startDialog(texts, bg, onDone) {
    if (Array.isArray(texts)) {
      state.dialogQueue = texts;
    } else {
      state.dialogQueue = [texts];
    }

    state.dialogIndex = 0;
    state.onDialogDone = onDone;
    setBackground(ui.dialogBg, bg || PHASES[0].bg);
    showScreen(ui.dialog);
    showDialogLine();
  }

  // começa a digiar a fala atual
  function showDialogLine() {
    clearTimeout(state.typeTimer);
    state.fullText = state.dialogQueue[state.dialogIndex] || "";
    state.typedLen = 0;
    state.typing = true;
    ui.dialogText.textContent = "";
    typeNextChar();
  }

  // efeitinho tipo maquina de escrever pra exibir o dialogo letra por letra
  function typeNextChar() {
    if (!state.typing) return;

    const chegouAoFim = state.typedLen >= state.fullText.length;
    if (chegouAoFim) {
      state.typing = false;
      return;
    }

    state.typedLen += 1;
    ui.dialogText.textContent = state.fullText.slice(0, state.typedLen);

    const tocaSom = state.typedLen % 2 === 0;
    if (tocaSom) {
      beep(620 + Math.random() * 80, 0.025, "square", 0.02);
    }

    state.typeTimer = setTimeout(typeNextChar, 28);
  }

  // mostra o texto completo de uma vez (pula toda a digitaçao)
  function finishTypingInstantly() {
    clearTimeout(state.typeTimer);
    state.typing = false;
    ui.dialogText.textContent = state.fullText;
  }

  // se tiver mais falas depois, passa para a próxima fala da fila, se nao termina
  function goToNextDialogLine() {
    state.dialogIndex += 1;

    if (state.dialogIndex < state.dialogQueue.length) {
      showDialogLine();
      return;
    }

    const callbackDeFim = state.onDialogDone;
    state.onDialogDone = null;
    if (callbackDeFim) {
      callbackDeFim();
    }
  }

  // pra quando o usuario for pular a frase
  function skipOrAdvanceDialog() {
    if (state.typing) {
      finishTypingInstantly();
      return;
    }
    goToNextDialogLine();
  }

  // funçoes pros meteoros 
  // remove todos os metoros
  function clearMeteors() {
    for (let i = 0; i < state.meteors.length; i++) {
      state.meteors[i].el.remove();
    }
    state.meteors = [];
    ui.meteorField.innerHTML = "";
    ui.laserLayer.innerHTML = "";
  }

  // verifica se ja existe um meteoro perto dessa posiçao X perto do topo da tela (pra nn nascer um em cima do outro)
  function isXPositionTaken(x, minDist = 80) {
    for (let i = 0; i < state.meteors.length; i++) {
      const m = state.meteors[i];
      const distancia = Math.abs(m.x - x);
      if (distancia < minDist && m.y < 120) {
        return true;
      }
    }
    return false;
  }

  // acha uma posiçao horizontal livre pra um meteoro nascer
  function findFreeXPosition(fieldWidth) {
    let x = 48 + Math.random() * Math.max(40, fieldWidth - 96);
    let tentativas = 0;

    while (isXPositionTaken(x) && tentativas < 8) {
      x = 48 + Math.random() * Math.max(40, fieldWidth - 96);
      tentativas += 1;
    }

    return x;
  }

  // cria o elemento html do meteoro com a conta dentro
  function createMeteorElement(x, data) {
    const el = document.createElement("div");
    el.className = "meteor";
    el.style.left = `${x}px`;
    el.style.top = `-80px`;

    const eq = document.createElement("div");
    eq.className = "meteor-eq";
    eq.textContent = formatEq(data.n1, data.op, data.n2);
    el.appendChild(eq);

    return el;
  }

  // spawna um meteoro (se tiver espaço e contas na fila)
  function spawnMeteor() {
    const phase = PHASES[state.phaseIndex];
    if (!phase || !state.playing) return;
    if (state.queue.length === 0) return;
    if (state.meteors.length >= phase.maxOnScreen) return;

    const fieldWidth = ui.meteorField.clientWidth || 400;
    const x = findFreeXPosition(fieldWidth);

    const data = state.queue.shift();
    const el = createMeteorElement(x, data);
    ui.meteorField.appendChild(el);

    state.meteors.push({
      el,
      x,
      y: -80,
      speed: phase.speed * (0.85 + Math.random() * 0.35),
      result: data.result,
      alive: true,
    });
  }

  // calcula (teoricamente) a trajetoria da nave até o meteoro pra disparar o laser (preciso dar uma olhada pq nn ta funcionando direito)
  function getLaserCoordinates(meteor) {
    const fieldRect = ui.meteorField.getBoundingClientRect();
    const rootRect = $("#game-root").getBoundingClientRect();
    const shipRect = ui.ship.getBoundingClientRect();

    const coordenadas = {
      meteorX: fieldRect.left + meteor.x - rootRect.left,
      meteorY: fieldRect.top + meteor.y + 36 - rootRect.top,
      shipX: shipRect.left + shipRect.width / 2 - rootRect.left,
      shipY: shipRect.top - rootRect.top,
    };

    return coordenadas;
  }

  // desenha o tiro do laser
  function playLaserEffect(meteor) {
    const coordenadas = getLaserCoordinates(meteor);

    const laser = document.createElement("div");
    laser.className = "laser";
    const altura = Math.max(20, coordenadas.shipY - coordenadas.meteorY);
    laser.style.left = `${coordenadas.shipX}px`;
    laser.style.top = `${coordenadas.meteorY}px`;
    laser.style.height = `${altura}px`;
    ui.laserLayer.appendChild(laser);
    removerElementoComAtraso(laser, 220);

    beep(980, 0.08, "sawtooth", 0.04);
    beep(1400, 0.06, "square", 0.03);
  }

  // tira um meteoro que foi atingido da lista de meteoros ativos
  function removerMeteorDaLista(meteorParaRemover) {
    const novaLista = [];

    for (let i = 0; i < state.meteors.length; i++) {
      if (state.meteors[i] !== meteorParaRemover) {
        novaLista.push(state.meteors[i]);
      }
    }

    state.meteors = novaLista;
  }

  // animaçao de impacto e remove o meteoro da lista de meteoros ativos (por enquanto deixei a aniimação do laser ativa pra gnt testar)
  function destroyMeteor(meteor, withLaser = true) {
    if (!meteor.alive) return;
    meteor.alive = false;

    if (withLaser) {
      playLaserEffect(meteor);
    }

    meteor.el.classList.add("hit");
    removerElementoComAtraso(meteor.el, 160);
    removerMeteorDaLista(meteor);
  }

  // funções envolvendo o jogador e mensagens na tela
  // tira uma vida do jogador, se acabarem as vidas o jogo termina
  function loseLife() {
    state.lives -= 1;
    updateHud();
    beep(120, 0.2, "sawtooth", 0.06);
    flashMessage("IMPACTO!");
    if (state.lives <= 0) {
      endDefeat();
    }
  }

  // mostra uma mensagem rápida na tela
  function flashMessage(text) {
    const msg = document.createElement("div");
    msg.className = "flash-msg";
    msg.textContent = text;
    ui.play.appendChild(msg);
    removerElementoComAtraso(msg, 900);
  }

  // converte o texto digitado em nmr (retorna null se nn for um nmr)
  function parseAnswer(rawValue) {
    const value = Number(rawValue);
    if (Number.isFinite(value)) {
      return value;
    }
    return null;
  }

  // procura qual meteoro tem o mesmo resultado do valor digitado (e esta mais proximo de bater no chao caso tenha mais de um com o mewsmo resultado)
  function findMeteorWithResult(value) {
    let melhorMeteoro = null;

    for (let i = 0; i < state.meteors.length; i++) {
      const m = state.meteors[i];
      if (!m.alive || m.result !== value) continue;

      if (melhorMeteoro === null || m.y > melhorMeteoro.y) {
        melhorMeteoro = m;
      }
    }

    return melhorMeteoro;
  }

  // executado quando o jogador disparar o laser
  function tryFire() {
    if (!state.playing) return;

    const raw = ui.answer.value.trim();
    if (raw === "") return;

    const value = parseAnswer(raw);
    ui.answer.value = "";
    if (value === null) return;

    const alvo = findMeteorWithResult(value);
    if (!alvo) {
      beep(180, 0.1, "triangle", 0.04);
      flashMessage("ERRO!");
      return;
    }

    destroyMeteor(alvo, true);
    state.score += POINTS_HIT;
    updateHud();
    checkPhaseClear();
  }

  // loop principal do jogo
  // move todos os meteoros para baixo e devolve os que bateram no chão
  function moveMeteorsDown(dt) {
    const fieldHeight = ui.meteorField.clientHeight || 400;
    const meteorosQueChegaramAoChao = [];

    for (let i = 0; i < state.meteors.length; i++) {
      const m = state.meteors[i];
      if (!m.alive) continue;

      m.y += m.speed * dt;
      m.el.style.top = `${m.y}px`;

      if (m.y + 72 >= fieldHeight) {
        meteorosQueChegaramAoChao.push(m);
      }
    }

    return meteorosQueChegaramAoChao;
  }

  // roda sem parar durante a fase (cria meteoros, move os que ja existem e verifica os impactos e fim de fase)
  function tick(ts) {
    if (!state.playing) return;
    if (!state.lastTs) state.lastTs = ts;

    const dt = Math.min(0.05, (ts - state.lastTs) / 1000);
    state.lastTs = ts;

    const phase = PHASES[state.phaseIndex];
    state.spawnAcc += dt * 1000;
    if (state.spawnAcc >= phase.spawnMs) {
      state.spawnAcc = 0;
      spawnMeteor();
    }

    const meteorosQueChegaramAoChao = moveMeteorsDown(dt);
    for (let i = 0; i < meteorosQueChegaramAoChao.length; i++) {
      const m = meteorosQueChegaramAoChao[i];
      destroyMeteor(m, false);
      loseLife();
    }

    if (!state.playing) return;

    if (state.queue.length === 0 && state.meteors.length === 0) {
      checkPhaseClear();
    } else {
      state.raf = requestAnimationFrame(tick);
    }
  }

  // fluxo geral do jogo
  // avança para a proxima fase ou mostra a tela de vitória final
  function aoTerminarDialogoDeVitoriaDaFase() {
    const isLastPhase = state.phaseIndex >= PHASES.length - 1;

    if (isLastPhase) {
      endVictory();
    } else {
      state.phaseIndex += 1;
      beginPhaseDialog();
    }
  }

  // verifica se a fase acabou 
  function checkPhaseClear() {
    const faseTerminou =
      state.queue.length === 0 && state.meteors.length === 0 && state.playing;
    if (!faseTerminou) return;

    state.playing = false;
    cancelAnimationFrame(state.raf);
    state.score += POINTS_PHASE;
    updateHud();

    const phase = PHASES[state.phaseIndex];
    startDialog(phase.win, phase.bg, aoTerminarDialogoDeVitoriaDaFase);
  }

  // Prepara e começa uma fase (limpa a tela, monta a fila de contas e starta o loop principal)
  function startPhasePlay() {
    const phase = PHASES[state.phaseIndex];
    clearMeteors();
    state.queue = buildQueue(phase);
    state.spawnAcc = 0;
    state.lastTs = 0;
    state.playing = true;
    setBackground(ui.playBg, phase.bg);
    updateHud();
    showScreen(ui.play);
    ui.answer.value = "";
    ui.answer.focus();
    spawnMeteor();
    state.raf = requestAnimationFrame(tick);
  }

  // mostra o titulo e a fala de introdução da fase
  function beginPhaseDialog() {
    const phase = PHASES[state.phaseIndex];
    startDialog(
      [`Fase ${state.phaseIndex + 1}: ${phase.title}`, phase.before],
      phase.bg,
      startPhasePlay
    );
  }

  // chamada quando termina a fala de derrota (pra mostrar a tela de gameover)
  function aoTerminarDialogoDeDerrota() {
    const phase = PHASES[state.phaseIndex];
    ui.goScore.textContent = String(state.score);
    ui.goQuote.textContent = `"${phase.lose}"`;
    showScreen(ui.gameover);
    beep(90, 0.35, "sawtooth", 0.05);
  }

  // quando o jogador perde todas as vidas (limpa os meteoros e mosttra a frase de derrota da fase)
  function endDefeat() {
    state.playing = false;
    cancelAnimationFrame(state.raf);
    clearMeteors();
    const phase = PHASES[state.phaseIndex];
    startDialog(phase.lose, phase.bg, aoTerminarDialogoDeDerrota);
  }

  // pra quando o jogador vence todas as fases (mostrar tela de vitoria)
  function endVictory() {
    state.playing = false;
    cancelAnimationFrame(state.raf);
    clearMeteors();
    ui.winScore.textContent = String(state.score);
    ui.winQuote.textContent = "A Terra foi salva. Lorde Void foi derrotado!";
    showScreen(ui.victory);
    beep(660, 0.12, "square", 0.04);
    tocarBeepComAtraso(880, 0.14, "square", 0.04, 120);
    tocarBeepComAtraso(1175, 0.2, "square", 0.045, 260);
  }

  // zera tudo (pra poder começar uma partida nova)
  function resetRun() {
    cancelAnimationFrame(state.raf);
    clearTimeout(state.typeTimer);
    clearMeteors();
    state.phaseIndex = 0;
    state.score = 0;
    state.lives = MAX_LIVES;
    state.playing = false;
    state.queue = [];
    updateHud();
  }

  // começa uma partida do zero (botao de iniciar ou vomeçar novo jogo)
  function startMission() {
    ensureAudio();
    resetRun();
    startDialog(INTRO_TEXT, PHASES[0].bg, beginPhaseDialog);
  }

  // funções pra interações com teclado e clique

  function aoClicarBotaoDisparar() {
    ensureAudio();
    tryFire();
    ui.answer.focus();
  }

  function aoPressionarTeclaNoCampoDeResposta(e) {
    if (e.key === "Enter") {
      e.preventDefault();
      ensureAudio();
      tryFire();
    }
  }

  function aoPressionarTeclaDuranteDialogo(e) {
    if (!ui.dialog.classList.contains("active")) return;

    if (e.key === " " || e.key === "Enter") {
      e.preventDefault();
      ensureAudio();
      skipOrAdvanceDialog();
    }
  }

  function aoClicarNaTelaDeDialogo() {
    ensureAudio();
    skipOrAdvanceDialog();
  }

  ui.btnStart.addEventListener("click", startMission);
  ui.btnFire.addEventListener("click", aoClicarBotaoDisparar);
  ui.btnRetry.addEventListener("click", startMission);
  ui.btnAgain.addEventListener("click", startMission);
  ui.answer.addEventListener("keydown", aoPressionarTeclaNoCampoDeResposta);
  document.addEventListener("keydown", aoPressionarTeclaDuranteDialogo);
  ui.dialog.addEventListener("click", aoClicarNaTelaDeDialogo);

  // iniciar jogo
  async function loadContas() {
    try {
      const res = await fetch("contas.json", { cache: "no-store" });
      if (!res.ok) throw new Error("fetch failed");
      const data = await res.json();
      state.contas = data;
    } catch(err){
      console.log(err)
    }
  }

  loadContas().then(() => {
    updateHud();
    showScreen(ui.title);
  });
})();